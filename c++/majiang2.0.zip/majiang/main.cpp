#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <queue>
#include <set>
#include <random>

#include "game.h"
using namespace std;

int main(){
    Game game{"王嘉成"};
    game.start();
    return 0;
}